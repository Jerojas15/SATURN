package tec.proyecto.saturn;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class AffinityActivity extends AppCompatActivity {

    private SessionActivity session = SessionActivity.getSession();
    List<Pair<String, Integer>> COURSE_RATES = session.getCourseRates();
    List<String> AFFINITY_RATES = new ArrayList<>();

    // UI
    private android.support.v7.app.ActionBar actionBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affinity);

        actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#015289")));

        // Nombre del profesor
        TextView professorName = (TextView) findViewById(R.id.professor_name);
        professorName.setText("Profesor: " + session.getName());

        // Posibles calificaciones
        AFFINITY_RATES.add("1");
        AFFINITY_RATES.add("2");
        AFFINITY_RATES.add("3");
        AFFINITY_RATES.add("4");
        AFFINITY_RATES.add("5");

        createAffinityRows();

    }

    private void createAffinityRows() {
        TableLayout affinityTable = (TableLayout) findViewById(R.id.affinity_table);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, AFFINITY_RATES);
        adapter.setDropDownViewResource(R.layout.custom_spinner_text);

        for (int i = 0; i <COURSE_RATES.size(); i++) {

            TableRow row= new TableRow(this);
            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT);
            row.setLayoutParams(lp);

            // Nombre del curso
            TextView tv1 = new TextView(this);
            tv1.setText(COURSE_RATES.get(i).first);
            tv1.setTextColor(Color.WHITE);
            tv1.setTextSize(15);
            tv1.setPadding(5, 20, 100, 5);

            // Calificación
            Spinner rate = new Spinner(this);
            rate.setAdapter(adapter);
            rate.getBackground().setColorFilter(getResources().getColor(R.color.spinner_arrow_color), PorterDuff.Mode.SRC_ATOP);
            rate.setSelection(COURSE_RATES.get(i).second - 1);
            rate.setId(i);
            final int temp = i;
            rate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> arg0, View arg1, int index, long value) {
                                updateRate(index, COURSE_RATES.get(temp).first,COURSE_RATES.get(temp).second - 1);
                            }
                            @Override
                            public void onNothingSelected(AdapterView<?> arg0) {

                            }
            });

            // Inserta en la línea
            row.addView(tv1);
            row.addView(rate);

            affinityTable.addView(row,i);
        }

    }

    public void updateRate(int index, String courseName, Integer rate) {
        COURSE_RATES.set(index, Pair.create(courseName, rate));
        session.updateAffinities(COURSE_RATES);
        //for(int i = 0; i < CURRENT_RATES.length; i++){
        //    System.out.println("i: " + i + "value: " + CURRENT_RATES[i]);
        //}
    }
}
