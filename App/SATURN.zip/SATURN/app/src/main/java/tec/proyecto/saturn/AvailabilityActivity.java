package tec.proyecto.saturn;

import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TabHost;
import android.widget.TextView;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TabHost;



public class AvailabilityActivity extends AppCompatActivity {

    private SessionActivity session = SessionActivity.getSession();

    // UI
    private android.support.v7.app.ActionBar actionBar;
    TabHost tabHost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_availability);

        actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#015289")));

        // Nombre del profesor
        TextView professorName = findViewById(R.id.professor_name);
        professorName.setText("Profesor: " + session.getName());

        // Tabs
        tabHost = (TabHost)findViewById(R.id.tabHost);
        tabHost.setup();

        //Tab Lunes
        TabHost.TabSpec spec = tabHost.newTabSpec("L");
        spec.setContent(R.id.l);
        spec.setIndicator("L");
        tabHost.addTab(spec);

        //Tab Martes
        spec = tabHost.newTabSpec("K");
        spec.setContent(R.id.k);
        spec.setIndicator("K");
        tabHost.addTab(spec);

        //Tab Miércoles
        spec = tabHost.newTabSpec("M");
        spec.setContent(R.id.m);
        spec.setIndicator("M");
        tabHost.addTab(spec);

        //Tab Jueves
        spec = tabHost.newTabSpec("J");
        spec.setContent(R.id.j);
        spec.setIndicator("J");
        tabHost.addTab(spec);

        //Tab Viernes
        spec = tabHost.newTabSpec("V");
        spec.setContent(R.id.v);
        spec.setIndicator("V");
        tabHost.addTab(spec);

        //Tab Sábado
        spec = tabHost.newTabSpec("S");
        spec.setContent(R.id.s);
        spec.setIndicator("S");
        tabHost.addTab(spec);


    }


}
