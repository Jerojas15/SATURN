package tec.proyecto.saturn;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    private SessionActivity session = SessionActivity.getSession();

    // UI
    private android.support.v7.app.ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#015289")));

        // Nombre del profesor
        TextView professorName = (TextView) findViewById(R.id.profile_professor_name);
        professorName.setText("Profesor: " + session.getName());

        Button mAvailabilityButton = (Button) findViewById(R.id.availability_button);
        mAvailabilityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goAvailabilityLayout();
            }
        });

        Button mAfinityButton = (Button) findViewById(R.id.affinity_button);
        mAfinityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goAffinityLayout();
            }
        });

    }

    private void goAvailabilityLayout() {
        Intent intent = new Intent(ProfileActivity.this, AvailabilityActivity.class);
        ProfileActivity.this.startActivity(intent);
    }

    private void goAffinityLayout() {
        Intent intent = new Intent(ProfileActivity.this, AffinityActivity.class);
        ProfileActivity.this.startActivity(intent);
    }

}


