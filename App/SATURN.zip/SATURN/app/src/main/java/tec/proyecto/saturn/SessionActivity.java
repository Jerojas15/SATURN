package tec.proyecto.saturn;

import android.util.Pair;

import java.util.ArrayList;
import java.util.List;

public class SessionActivity {

    private static SessionActivity session = new SessionActivity();
    private static  String username;

    private SessionActivity (){}

    public static SessionActivity getSession(){
        if (session == null) {
            session = new SessionActivity();
        }
        return session;
    }

    public void setUsername(String username) {

        this.username = username;
    }

    public String getUsername() {

        return username;
    }

    /*
        SQL: devuelve el nombre del profesor según username
     */
    public String getName() {
        return "Rodrigo";
    }

    /*
        SQL: devuelve nombres de cursos disponibles según el username
     */
    public String[] getCourses() {
        return  new String[]{
                "Introducción a la Programación", "Redes", "Introducción a Sistemas Operativos", "Inteligencia Artificial", "Estructuras de Datos"
        };
    }

    /*
        SQL: devuelve usernames y passwords disponibles
     */
    public String [] getUsernames() {
        return new String[]{
                "foo@example.com:hello", "bar@example.com:world", "profe:1234"
        };
    }

    /*
        SQL: PENSAR CÓMO SACAR CURSOS(NOMBRES) Y AFINIDADES
     */
    public int[] getRates() {
        return new int[] {
                1, 1, 1, 1, 1
        };
    }

    public List<Pair<String,Integer>> getCourseRates() {
        ArrayList list = new ArrayList<Pair<String, Integer>>();
        list.add(new Pair<>("Introducción a la Programación", 1));
        list.add(new Pair<>("Redes", 1));
        list.add(new Pair<>("Introducción a Sistemas Operativos", 1));
        list.add(new Pair<>("Inteligencia Artificial", 1));
        list.add(new Pair<>("Estructuras de Datos", 1));
        return list;
    }

    public void updateAffinities(List<Pair<String,Integer>> courseRates){

    }
}
