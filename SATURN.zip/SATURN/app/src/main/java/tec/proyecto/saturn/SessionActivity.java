package tec.proyecto.saturn;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

import android.util.Pair;
import java.util.ArrayList;
import java.util.List;

public class SessionActivity {

    private static SessionActivity session = new SessionActivity();
    private static  String username;
    private static int careerId,userId;
    private static String URL = "http://172.28.130.151:8080";
    private SessionActivity (){}

    public static SessionActivity getSession(){
        if (session == null) {
            session = new SessionActivity();
        }
        return session;
    }


    public static int getCareerId() {
        return careerId;
    }

    public static void setCareerId(int careerId) {
        SessionActivity.careerId = careerId;
    }

    public static int getUserId() {
        return userId;
    }

    public static void setUserId(int userId) {
        SessionActivity.userId = userId;
    }

    public void setUsername(String username) {

        this.username = username;
    }

    /*
        SQL: devuelve el nombre del profesor según username
     */
    public String getName() {
        return username;
    }


    /*
        SQL: devuelve cursos y afinidades
     */
    public List<Pair<Pair<String,Integer>,Integer>> getCourseRates() {
        InputStream inputStream = null;
        InputStream inputStream2 = null;
        HttpClient client = new DefaultHttpClient();//Se piden cursos
        HttpGet request = new HttpGet(URL+"/SATURN/rest/courses/careerId/"+getCareerId());

        HttpClient client2 = new DefaultHttpClient();//se piden afinidades
        HttpGet request2 = new HttpGet(URL+"/SATURN/rest/teachers/afinities/"+getUserId());
        HttpResponse response = null;
        HttpResponse response2 = null;
        try {
            response = client.execute(request);
            response2 = client2.execute(request2);
        } catch (IOException e) {
            e.printStackTrace();
        }
        JSONArray answer = null;
        JSONArray answer2 = null;
        try {
            inputStream = response.getEntity().getContent();
            String text = convertInputStreamToString(inputStream);
            answer = new JSONArray(text);


            inputStream2 = response2.getEntity().getContent();
            String text2 = convertInputStreamToString(inputStream2);
            answer2 = new JSONArray(text2);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ArrayList list = new ArrayList<Pair<Pair<String,Integer>, Integer>>();
        boolean set = false;
        for (int i = 0;i<answer.length();i++){
            set = false;
            for(int j = 0;j<answer2.length();j++){
                try {
                    if(answer.getJSONObject(i).getInt("courseId") == answer2.getJSONObject(j).getInt("courseId")) {
                        list.add(new Pair<>(new Pair<>(answer.getJSONObject(i).getString("name"),answer.getJSONObject(i).getInt("courseId")), answer2.getJSONObject(j).getInt("level")));
                        set = true;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            if(!set){
                try {
                    list.add(new Pair<>(new Pair<>(answer.getJSONObject(i).getString("name"),answer.getJSONObject(i).getInt("courseId")), 1));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        return list;
    }

    /*
        SQL: update afinidad de cursp
     */
    public void updateAffinities(List<Pair<Pair<String,Integer>,Integer>> courseRates){
        JSONArray list = new JSONArray();
        for(int i = 0;i<courseRates.size();i++) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("professorId", userId);
                obj.put("courseId", courseRates.get(i).first.second);
                obj.put("level", (courseRates.get(i).second>0)?courseRates.get(i).second:1);
                list.put(obj);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        String URL2 = URL+"/SATURN/rest/teachers/afinities";
        InputStream inputStream = null;
        boolean result = false;
        try {
            // 1. create HttpClient
            HttpClient httpclient = new DefaultHttpClient();
            // 2. make POST request to the given URL
            HttpPost httpPost = new HttpPost(URL2);
            String json = "";
            // 4. convert JSONObject to JSON to String
            json = list.toString();
            System.out.println(json);
            // 5. set json to StringEntity
            StringEntity se = new StringEntity(json);
            // 6. set httpPost Entity
            httpPost.setEntity(se);
            // 7. Set some headers to inform server about the type of the content
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            // 8. Execute POST request to the given URL
            HttpResponse httpResponse = httpclient.execute(httpPost);
            // 9. receive response as inputStream
            inputStream = httpResponse.getEntity().getContent();
        } catch (Exception e) {
            System.out.println("ERROR");
        }
    }

    public boolean checkCredentials(String mUsername, String mPassword){
        String URL2 = URL+"/SATURN/rest/login";
        InputStream inputStream = null;
        boolean result = false;
        try {
            // 1. create HttpClient
            HttpClient httpclient = new DefaultHttpClient();
            // 2. make POST request to the given URL
            HttpPost httpPost = new HttpPost(URL2);
            String json = "";
            // 3. build jsonObject
            JSONObject jsonObject = new JSONObject();
            jsonObject.accumulate("email", mUsername);
            jsonObject.accumulate("password", mPassword);
            // 4. convert JSONObject to JSON to String
            json = jsonObject.toString();
            // 5. set json to StringEntity
            StringEntity se = new StringEntity(json);
            // 6. set httpPost Entity
            httpPost.setEntity(se);
            // 7. Set some headers to inform server about the type of the content
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            // 8. Execute POST request to the given URL
            HttpResponse httpResponse = httpclient.execute(httpPost);
            // 9. receive response as inputStream
            inputStream = httpResponse.getEntity().getContent();
            String text = convertInputStreamToString(inputStream);
            JSONObject answer = new JSONObject(text);
            System.out.println(answer.getString("name"));
            // 10. convert inputstream to string
            if(answer.getString("status").equals("OK") && answer.getInt("userType") == 3) {
                setUsername(answer.getString("name"));
                setCareerId(answer.getInt("careerId"));
                setUserId(answer.getInt("userId"));
                result = true;
            }else {
                result = false;
            }

        } catch (Exception e) {
            System.out.println("ERROR");
        }
        return result;
    }

    private static String convertInputStreamToString(InputStream inputStream) throws IOException{
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }

    public List<Pair< Pair<Integer,Integer>, Integer>> getAvailabilities() {
        InputStream inputStream = null;
        HttpClient client = new DefaultHttpClient();//Se piden cursos
        HttpGet request = new HttpGet(URL+"/SATURN/rest/teachers/availabilities/"+getUserId());

        HttpResponse response = null;
        try {
            response = client.execute(request);
        } catch (IOException e) {
            e.printStackTrace();
        }
        JSONArray answer = null;
        try {
            inputStream = response.getEntity().getContent();
            String text = convertInputStreamToString(inputStream);
            answer = new JSONArray(text);
            System.out.println(answer);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ArrayList list = new ArrayList<Pair< Pair<Integer,Integer>, Integer>>();
        for(int i = 0; i<answer.length();i++){
            try {
                list.add(new Pair<>(new Pair<>(answer.getJSONObject(i).getInt("startHour"),answer.getJSONObject(i).getInt("endHour")),answer.getJSONObject(i).getInt("day")));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    public void updateAvailability(Integer day, Integer start, Integer end) {
        JSONObject obj = new JSONObject();
        JSONArray list = new JSONArray();
        try {
            obj.put("day", day);
            obj.put("startHour", start);
            obj.put("endHour", end);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        list.put(obj);
        String URL2 = URL+"/SATURN/rest/teachers/availabilities/"+getUserId();
        InputStream inputStream = null;
        boolean result = false;
        try {
            // 1. create HttpClient
            HttpClient httpclient = new DefaultHttpClient();
            // 2. make POST request to the given URL
            HttpPut httpPost = new HttpPut(URL2);
            String json = "";
            // 4. convert JSONObject to JSON to String
            json = list.toString();
            System.out.println(json);
            // 5. set json to StringEntity
            StringEntity se = new StringEntity(json);
            // 6. set httpPost Entity
            httpPost.setEntity(se);
            // 7. Set some headers to inform server about the type of the content
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            // 8. Execute POST request to the given URL
            HttpResponse httpResponse = httpclient.execute(httpPost);
            // 9. receive response as inputStream
            inputStream = httpResponse.getEntity().getContent();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
