package tec.proyecto.saturn;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class AffinityActivity extends AppCompatActivity {

    private SessionActivity session = SessionActivity.getSession();
    List<Pair<Pair<String,Integer>, Integer>> COURSE_RATES;
    List<String> AFFINITY_RATES = new ArrayList<>();

    // UI
    private android.support.v7.app.ActionBar actionBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affinity);

        actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#015289")));

        // Nombre del profesor
        TextView professorName = (TextView) findViewById(R.id.professor_name);
        professorName.setText("Profesor: " + session.getName());

        // Posibles calificaciones
        AFFINITY_RATES.add("1");
        AFFINITY_RATES.add("2");
        AFFINITY_RATES.add("3");
        AFFINITY_RATES.add("4");
        AFFINITY_RATES.add("5");

        AffinityTask affTask = new AffinityTask();
        affTask.execute((Void) null);

    }

    private void createAffinityRows() {
        TableLayout affinityTable = (TableLayout) findViewById(R.id.affinity_table);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, AFFINITY_RATES);
        adapter.setDropDownViewResource(R.drawable.custom_spinner_text);

        for (int i = 0; i <COURSE_RATES.size(); i++) {

            TableRow row= new TableRow(this);
            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT);
            row.setLayoutParams(lp);

            // Nombre del curso
            TextView tv1 = new TextView(this);
            tv1.setText(COURSE_RATES.get(i).first.first);
            tv1.setTextColor(Color.WHITE);
            tv1.setTextSize(15);
            tv1.setPadding(5, 20, 100, 5);

            // Calificación
            Spinner rate = new Spinner(this);
            rate.setAdapter(adapter);
            rate.getBackground().setColorFilter(getResources().getColor(R.color.spinner_arrow_color), PorterDuff.Mode.SRC_ATOP);
            rate.setSelection(COURSE_RATES.get(i).second-1);
            rate.setId(i);
            final int temp = i;
            rate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View arg1, int index, long value) {
                                System.out.println(parent.getItemAtPosition(index).toString());
                                updateRate(temp, COURSE_RATES.get(temp).first.first, Integer.parseInt(parent.getItemAtPosition(index).toString()));
                            }
                            @Override
                            public void onNothingSelected(AdapterView<?> arg0) {

                            }
            });

            // Inserta en la línea
            row.addView(tv1);
            row.addView(rate);

            affinityTable.addView(row,i);
        }

    }

    public void updateRate(int index, String courseName, Integer rate) {
        COURSE_RATES.set(index, Pair.create(Pair.create(courseName,COURSE_RATES.get(index).first.second), rate));
        AffinityUpdateTask update = new AffinityUpdateTask();
        update.execute((Void) null);
    }

    public class AffinityTask extends AsyncTask<Void, Void, Boolean> {

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.
            COURSE_RATES = (ArrayList) session.getCourseRates();
            return true;

        }

        @Override
        protected void onPostExecute(final Boolean success) {
            createAffinityRows();
        }

        @Override
        protected void onCancelled() {

        }
    }

    public class AffinityUpdateTask extends AsyncTask<Void, Void, Boolean> {

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.
            session.updateAffinities(COURSE_RATES);
            return true;

        }

        @Override
        protected void onPostExecute(final Boolean success) {

        }

        @Override
        protected void onCancelled() {

        }
    }
}

