package model;

public class Afinity {
    
        private int professorId;
        private int courseId;
        private int level;

        public int getProfessorId() {
            return professorId;
        }

        public void setProfessorId(int professorId) {
            this.professorId = professorId;
        }

        public int getCourseId() {
            return courseId;
        }

        public void setCourseId(int courseId) {
            this.courseId = courseId;
        }

        public int getLevel() {
            return level;
        }

        public void setLevel(int level) {
            this.level = level;
        }
    
}
